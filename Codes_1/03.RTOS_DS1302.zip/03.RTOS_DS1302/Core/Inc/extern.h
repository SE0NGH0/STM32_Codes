extern void led_main(void);
extern void button_led_toggle_test(void);
extern void ds1302_main(void);
