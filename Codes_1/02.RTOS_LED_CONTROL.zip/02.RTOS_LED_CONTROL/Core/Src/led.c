#include "led.h"

void led_main(void)
{
	while(1)
	{
//		(*GPIOB).ODR |= GPIO_PIN_0; // LED가 ON
//		GPIOB->ODR ^= GPIO_PIN_1; // LED1 toggle 반전
//		HAL_Delay(500);
//		GPIOB->ODR &= ~GPIO_PIN_0; // LED가 OFF
//		HAL_Delay(500);

//		led_all_on();
//		HAL_Delay(500);
//		led_all_off();
//		HAL_Delay(500);

		shift_left_led_on();
		shift_right_led_on();
		shift_left_keep_ledon();
		shift_right_keep_ledon();
		flower_on();
		flower_off();
	}
}

void led_all_on(void)
{
#if 1 // 구조체 pointer member
	GPIOB->ODR = 0xff;
#endif
#if 0 // DMA
	// printf("int %d\n", sizeof(int)); // 4로 찍히는지 확인
	*(unsigned int *)GPIOB_ODR = 0xff;
#endif
#if 0 // HAL
//	HAL_GPIO_WritePin(GPIOB, 0xff, 1);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
			GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 1);
#endif
}

void led_all_off(void)
{
#if 1 // 구조체 pointer member
	GPIOB->ODR = 0x00;
#endif
#if 0 // DMA
	// printf("int %d\n", sizeof(int)); // 4로 찍히는지 확인
	*(unsigned int *)GPIOB_ODR = 0x00;
#endif
#if 0 // HAL
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
			GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0);
#endif
}

void shift_left_led_on(void)
{
#if 1 // 구조체 pointer member
	for(int i = 0; i < 8; i++)
	{
		GPIOB->ODR = 0x01 << i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
#if 0 // DMA
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR = 0x01 << i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
}

void shift_right_led_on(void)
{
#if 1 // 구조체 pointer member
	for(int i = 0; i < 8; i++)
	{
		GPIOB->ODR = 0x80 >> i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
#if 0 // DMA
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR = 0x80 >> i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 7; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
}

void shift_left_keep_ledon(void)
{
#if 1 // 구조체 pointer member
	for(int i = 0; i < 8; i++)
	{
		GPIOB->ODR |= 0x01 << i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // DMA
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x01 << i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void shift_right_keep_ledon(void)
{
#if 1 // 구조체 pointer member
	for(int i = 0; i < 8; i++)
	{
		GPIOB->ODR |= 0x80 >> i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // DMA
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x80 >> i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 7; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void flower_on(void)
{
#if 1 // 구조체 pointer member
	for(int i = 0; i < 4; i++)
	{
		GPIOB->ODR |= 0x10 << i | 0x08 >> i;
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // DMA
	for(int i = 0; i < 4; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x10 << i | 0x08 >> i;
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 4; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i] | ledpins[7 - i], 1);
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void flower_off(void)
{
#if 1 // 구조체 pointer member
	led_all_on();
	HAL_Delay(100);
	for(int i = 4; i >= 0; i--)
	{
		GPIOB->ODR &= ~(0x10 << i | 0x08 >> i);
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // DMA
	led_all_on();
	HAL_Delay(100);
	for(int i = 4; i >= 0; i--)
	{
		*(unsigned int*)GPIOB_ODR &= ~(0x10 << i | 0x08 >> i);
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
#if 0 // HAL
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	led_all_on();
	HAL_Delay(100);

	for(int i = 0; i < 4; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i] | ledpins[7 - i], 0);
		HAL_Delay(150);
	}

	HAL_Delay(100);
#endif
}
