#include "led.h"

void led_main(void)
{
	while(1)
	{
		led_all_on();
		HAL_Delay(500);
		led_all_off();
		HAL_Delay(500);

		shift_left_led_on();
		shift_right_led_on();
		shift_left_keep_ledon();
		shift_right_keep_ledon();
		flower_on();
		flower_off();
	}
}

void led_all_on(void)
{
#if 1
	// printf("int %d\n", sizeof(int)); // 4로 찍히는지 확인
	*(unsigned int *)GPIOB_ODR = 0xff;
#else // original
//	HAL_GPIO_WritePin(GPIOB, 0xff, 1);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
			GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 1);
#endif
}

void led_all_off(void)
{
#if 1
	// printf("int %d\n", sizeof(int)); // 4로 찍히는지 확인
	*(unsigned int *)GPIOB_ODR = 0x00;
#else
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
			GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0);
#endif
}

void shift_left_led_on(void)
{
#if 1
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR = 0x01 << i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
}

void shift_right_led_on(void)
{
#if 1
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR = 0x80 >> i;
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 7; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
		led_all_off();
	}
	HAL_Delay(100);
#endif
}

void shift_left_keep_ledon(void)
{
#if 1
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x01 << i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void shift_right_keep_ledon(void)
{
#if 1
	for(int i = 0; i < 8; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x80 >> i;
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 7; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i], 1);
		HAL_Delay(100);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void flower_on(void)
{
#if 1
	for(int i = 0; i < 4; i++)
	{
		*(unsigned int*)GPIOB_ODR |= 0x10 << i | 0x08 >> i;
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	for(int i = 4; i >= 0; i--)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i] | ledpins[7 - i], 1);
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#endif
}

void flower_off(void)
{
#if 1
	led_all_on();
	HAL_Delay(100);
	for(int i = 4; i >= 0; i--)
	{
		*(unsigned int*)GPIOB_ODR &= ~(0x10 << i | 0x08 >> i);
		HAL_Delay(150);
	}
	led_all_off();
	HAL_Delay(100);
#else
	uint16_t ledpins[8] = {
			GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3,
			GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
	};

	led_all_on();
	HAL_Delay(100);

	for(int i = 0; i < 4; i++)
	{
		HAL_GPIO_WritePin(GPIOB, ledpins[i] | ledpins[7 - i], 0);
		HAL_Delay(150);
	}

	HAL_Delay(100);
#endif
}
