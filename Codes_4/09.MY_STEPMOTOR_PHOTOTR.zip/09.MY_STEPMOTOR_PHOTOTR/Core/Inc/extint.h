/*
 * extint.h
 *
 *  Created on: Apr 8, 2025
 *      Author: microsoft
 */

#ifndef INC_EXTINT_H_
#define INC_EXTINT_H_

#include "main.h"

#endif /* INC_EXTINT_H_ */
