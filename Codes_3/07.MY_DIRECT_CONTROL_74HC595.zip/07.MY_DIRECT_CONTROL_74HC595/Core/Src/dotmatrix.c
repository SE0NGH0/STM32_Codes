#if 1
#include "main.h"
#include "button.h"

void init_dotmatrix(void);
int dotmatrix_main_func(void);

uint8_t smile[] = {			// 스마일 문자 정의
	0b00111100,
	0b01000010,
	0b10010101,
	0b10100001,
	0b10100001,
	0b10010101,
	0b01000010,
	0b00111100
};

uint8_t up_arrow_data[20][10] =
{
	{
		0b00011000,
		0b00111100,
		0b01111110,
		0b11111111,
		0b00111100,
		0b00111100,
		0b00111100,
		0b00000000
	},
	{
		0b00011000,
		0b00111100,
		0b01111110,
		0b11111111,
		0b00111100,
		0b00111100,
		0b00111100,
		0b00000000
	}
};

uint8_t down_arrow_data[20][10] =
{
	{
		0b00000000,
		0b00111100,
		0b00111100,
		0b00111100,
		0b11111111,
		0b01111110,
		0b00111100,
		0b00011000
	},
	{
		0b00000000,
		0b00111100,
		0b00111100,
		0b00111100,
		0b11111111,
		0b01111110,
		0b00111100,
		0b00011000
	}
};

uint8_t col[2] = {0, 0};

uint8_t number_data[20][10] =
{
	{
		0b01001010, // 박
		0b01001010,
		0b01111011,
		0b01001010,
		0b01111010,
		0b00000000,
		0b01111110,
		0b00000010
	},
	{
		0b00010001, // 성
		0b00100001,
		0b01010111,
		0b10001001,
		0b00000001,
		0b00111100,
		0b01000010,
		0b00111100
	},
	{
		0b00010000, // 호
		0b01111100,
		0b00000000,
		0b00111000,
		0b01000100,
		0b00111000,
		0b00010000,
		0b01111100
	},
	{
		0b00111100, // smile
		0b01000010,
		0b10100101,
		0b10000001,
		0b10100101,
		0b10011001,
		0b01000010,
		0b00111100
	}
};

void direct(uint8_t* data, uint8_t len)
{
    uint8_t temp;
    for (int j = 0; j < len; j++)
    {
        for (int k = 0; k < 8; k++)
        {
            temp = data[j];
            if (temp & (1 << k))
                HAL_GPIO_WritePin(GPIOB, SER_74HC595_Pin, 1);
            else
                HAL_GPIO_WritePin(GPIOB, SER_74HC595_Pin, 0);

            // CLK 펄스: 상승 -> 하강
            HAL_GPIO_WritePin(GPIOB, CLK_74HC595_Pin, 1);
            HAL_GPIO_WritePin(GPIOB, CLK_74HC595_Pin, 0);
        }
    }
}

unsigned char display_data[8];  // 최종 8x8 출력할 데이터
unsigned char scroll_buffer[50][8] = {0};  // 스코롤할 데이타가 들어있는 버퍼
int number_of_character = 4;  // 출력할 문자 갯수

// 초기화 작업
// 1. display_data에 number_data[0]에 있는 내용 복사
// 2. number_data를 scroll_buffer에 복사
// 3. dotmatrix의 led를 off
void init_dotmatrix(void)
{
	for (int i=0; i < 8; i++)
	{
		display_data[i] = number_data[i];
	}
	for (int i=1; i < number_of_character+1; i++)
	{
		for (int j=0; j < 8; j++) // scroll_buffer[0] = blank
		{
			scroll_buffer[i][j] = number_data[i-1][j];
		}
	}
}

// scroll 문자 출력 프로그램
int dotmatrix_main_func(void)
{
    // 스크롤 애니메이션을 위한 카운터와 인덱스 변수 선언
    static int count = 0;
    static int index = 0;
    // 마지막 스크롤 업데이트 시각을 저장하는 변수 (ms 단위)
    static uint32_t past_time = 0;

    // 도트매트릭스의 동작 상태를 정의하는 열거형 (상태 머신)
    typedef enum {
        IDLE_STATE,      // 기본 스크롤 모드 상태
        UP_ARROW_STATE,  // 위쪽 화살표 애니메이션 상태
        DOWN_ARROW_STATE // 아래쪽 화살표 애니메이션 상태
    } DotMatrixState;

    // 현재 상태를 저장, 초기값은 IDLE_STATE (기본 스크롤 상태)
    static DotMatrixState state = IDLE_STATE;
    // 화살표 상태 시작 시간과 화살표 프레임 업데이트 타이머
    static uint32_t arrowStateStart = 0;
    static uint32_t arrowFrameTimer = 0;

    // 각 기능별 동작 지연 시간 상수 (ms 단위)
    const uint32_t SCROLL_DELAY = 500;      // 스크롤 업데이트 간격: 500ms
    const uint32_t ARROW_DURATION = 30000;    // 화살표 애니메이션 전체 지속 시간: 30000ms (30초)
    const uint32_t ARROW_FRAME_PERIOD = 200;  // 화살표 프레임 업데이트 간격: 200ms

    // 도트매트릭스 하드웨어 초기화
    init_dotmatrix();

    // 버튼 입력을 읽기 위한 변수 초기화 (초기 상태는 버튼이 눌리지 않음)
    static GPIO_PinState lastBtnState = GPIO_PIN_RESET;
    HAL_Delay(50);  // 하드웨어 안정화를 위한 딜레이
    lastBtnState = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_0);  // 초기 버튼 상태 읽기

    // 위쪽 화살표 애니메이션에 사용할 디스플레이 버퍼 및 프레임 관련 변수
    static uint8_t up_arrow_disp[8];
    static int up_currentFrame = 0;
    static int up_nextRow = 0;

    // 아래쪽 화살표 애니메이션에 사용할 디스플레이 버퍼 및 프레임 관련 변수
    static uint8_t down_arrow_disp[8];
    static int down_currentFrame = 0;
    static int down_nextRow = 0;

    // 메인 루프: 도트매트릭스의 동작을 계속 반복 실행
    while (1)
    {
        // 현재 시간을 ms 단위로 가져옴
        uint32_t now = HAL_GetTick();
        // 현재 버튼 상태를 읽어옴
        GPIO_PinState btnState = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_0);

        // 현재 상태에 따른 동작 분기
        switch (state)
        {
            case IDLE_STATE:
                // 기본 스크롤 모드:
                // 일정 시간(SCROLL_DELAY)마다 스크롤 버퍼에서 데이터를 읽어와서 display_data에 저장
                if (now - past_time >= SCROLL_DELAY)
                {
                    past_time = now;  // 마지막 업데이트 시간 갱신
                    for (int i = 0; i < 8; i++)
                    {
                        // 현재 문자(scroll_buffer[index])와 다음 문자(scroll_buffer[index+1])의 데이터를
                        // bit 단위로 시프트하여 부드러운 스크롤 효과 구현
                        display_data[i] = (scroll_buffer[index][i] >> count) |
                                          (scroll_buffer[index+1][i] << (8 - count));
                    }
                    // 카운터 증가, 한 문자(8 비트) 스크롤이 완료되면 다음 문자로 전환
                    if (++count == 8)
                    {
                        count = 0;
                        index++;
                        if (index == number_of_character + 1)
                            index = 0; // 문자의 끝에 도달하면 처음부터 반복
                    }
                }

                // 도트매트릭스에 display_data를 출력
                for (int i = 0; i < 8; i++)
                {
                    // 해당 행(i)를 선택: 행 선택을 위해 한 비트만 0으로 만들고 나머지는 1로 설정
                    col[0] = ~(1 << i);
                    // 해당 행에 출력할 데이터를 설정
                    col[1] = display_data[i];
                    // 출력 함수 호출 (두 개의 데이터 전달)
                    direct(col, 2);
                    // 클럭 펄스 생성 (GPIOB의 핀 13을 토글)
                    GPIOB->ODR &= ~GPIO_PIN_13;
                    GPIOB->ODR |= GPIO_PIN_13;
                    HAL_Delay(1);
                }

                // 버튼의 상태 변화 감지: 버튼이 눌렸다면 (비교: 이전 상태와 현재 상태)
                if (btnState == GPIO_PIN_SET && lastBtnState == GPIO_PIN_RESET)
                {
                    // 버튼 눌림 이벤트가 발생하면 위쪽 화살표 애니메이션 상태로 전환
                    state = UP_ARROW_STATE;
                    arrowStateStart = now;  // 애니메이션 시작 시간 저장
                    arrowFrameTimer = now;  // 프레임 업데이트 타이머 초기화

                    // 현재 프레임의 위쪽 화살표 데이터를 up_arrow_disp 배열에 복사
                    for (int i = 0; i < 8; i++)
                    {
                        up_arrow_disp[i] = up_arrow_data[up_currentFrame][i];
                    }
                    up_nextRow = 0;  // 다음에 추가할 행의 인덱스 초기화
                }
                break;

            case UP_ARROW_STATE:
                // 위쪽 화살표 애니메이션 상태

                // 만약 버튼이 다시 눌리면, 아래쪽 화살표 애니메이션 상태로 전환
                if (btnState == GPIO_PIN_SET && lastBtnState == GPIO_PIN_RESET)
                {
                    state = DOWN_ARROW_STATE;
                    arrowStateStart = now;
                    arrowFrameTimer = now;

                    // 현재 프레임의 아래쪽 화살표 데이터를 down_arrow_disp 배열에 복사
                    for (int i = 0; i < 8; i++)
                    {
                        down_arrow_disp[i] = down_arrow_data[down_currentFrame][i];
                    }
                    down_nextRow = 0;
                }
                // 화살표 애니메이션이 설정된 지속 시간(ARROW_DURATION)이 지난 경우
                else if (now - arrowStateStart >= ARROW_DURATION)
                {
                    // 기본 스크롤 상태로 복귀
                    state = IDLE_STATE;
                    past_time = now;
                }
                else
                {
                    // ARROW_FRAME_PERIOD 시간마다 위쪽 화살표 애니메이션 프레임 업데이트
                    if (now - arrowFrameTimer >= ARROW_FRAME_PERIOD)
                    {
                        // 디스플레이 버퍼 내의 데이터들을 한 줄씩 위로 이동 (스크롤 효과)
                        for (int i = 0; i < 7; i++)
                        {
                            up_arrow_disp[i] = up_arrow_disp[i+1];
                        }
                        // 마지막 행(인덱스 7)에 새로운 데이터를 추가
                        // (up_currentFrame + 1) % 2 를 통해 두 프레임을 번갈아 사용
                        up_arrow_disp[7] = up_arrow_data[(up_currentFrame + 1) % 2][up_nextRow];
                        up_nextRow++;  // 다음에 추가할 행의 인덱스를 증가

                        // 만약 한 프레임의 모든 행(8행)이 사용되었다면,
                        if (up_nextRow >= 8)
                        {
                            up_nextRow = 0;  // 행 인덱스 리셋
                            // 현재 프레임을 다음 프레임으로 전환 (0과 1 사이를 번갈아)
                            up_currentFrame = (up_currentFrame + 1) % 2;
                        }
                        arrowFrameTimer = now;  // 프레임 업데이트 시간 갱신
                    }

                    // up_arrow_disp 배열의 데이터를 도트매트릭스에 출력
                    for (int i = 0; i < 8; i++)
                    {
                        col[0] = ~(1 << i);
                        col[1] = up_arrow_disp[i];
                        direct(col, 2);
                        GPIOB->ODR &= ~GPIO_PIN_13;
                        GPIOB->ODR |= GPIO_PIN_13;
                        HAL_Delay(1);
                    }
                }
                break;

            case DOWN_ARROW_STATE:
                // 아래쪽 화살표 애니메이션 상태

                // 버튼이 눌리면 다시 위쪽 화살표 상태로 전환
                if (btnState == GPIO_PIN_SET && lastBtnState == GPIO_PIN_RESET)
                {
                    state = UP_ARROW_STATE;
                    arrowStateStart = now;
                    arrowFrameTimer = now;

                    // 위쪽 화살표 데이터 초기화
                    for (int i = 0; i < 8; i++)
                    {
                        up_arrow_disp[i] = up_arrow_data[up_currentFrame][i];
                    }
                    up_nextRow = 0;
                }
                // 애니메이션 지속 시간이 끝나면 기본 스크롤 상태로 전환
                else if (now - arrowStateStart >= ARROW_DURATION)
                {
                    state = IDLE_STATE;
                    past_time = now;
                }
                else
                {
                    // ARROW_FRAME_PERIOD 시간마다 아래쪽 화살표 애니메이션 프레임 업데이트
                    if (now - arrowFrameTimer >= ARROW_FRAME_PERIOD)
                    {
                        // 디스플레이 버퍼 내의 데이터들을 한 줄씩 아래로 이동 (역방향 스크롤 효과)
                        for (int i = 7; i > 0; i--)
                        {
                            down_arrow_disp[i] = down_arrow_disp[i-1];
                        }
                        // 첫 번째 행(인덱스 0)에 새로운 데이터를 추가
                        // 여기서는 down_arrow_data 배열의 (down_currentFrame + 1) % 2 프레임에서 데이터를 읽으며,
                        // 7 - down_nextRow 인덱스를 사용해 역순으로 데이터를 넣음
                        down_arrow_disp[0] = down_arrow_data[(down_currentFrame + 1) % 2][7 - down_nextRow];
                        down_nextRow++;  // 다음 행 인덱스 증가

                        // 한 프레임의 모든 행을 사용했다면,
                        if (down_nextRow >= 8)
                        {
                            down_nextRow = 0;  // 행 인덱스 리셋
                            // 현재 프레임을 다음 프레임으로 전환 (0과 1 사이를 번갈아)
                            down_currentFrame = (down_currentFrame + 1) % 2;
                        }
                        arrowFrameTimer = now;  // 프레임 업데이트 시간 갱신
                    }

                    // down_arrow_disp 배열의 데이터를 도트매트릭스에 출력
                    for (int i = 0; i < 8; i++)
                    {
                        col[0] = ~(1 << i);
                        col[1] = down_arrow_disp[i];
                        direct(col, 2);
                        GPIOB->ODR &= ~GPIO_PIN_13;
                        GPIOB->ODR |= GPIO_PIN_13;
                        HAL_Delay(1);
                    }
                }
                break;
        }

        // 현재 버튼 상태를 이전 버튼 상태에 저장 (다음 루프에서 버튼 상태 변화 감지용)
        lastBtnState = btnState;
        HAL_Delay(10);  // 루프 간 짧은 딜레이
    }
    return 0;
}
#endif

#if 0
#include "main.h"

void dotmatrix_main_test();
void init_dotmatrix(void);
int dotmatrix_main(void);
int dotmatrix_main_func(void);

uint8_t allon[] = {			// allon 문자 정의
	0b11111111,
	0b11111111,
	0b11111111,
	0b11111111,
	0b11111111,
	0b11111111,
	0b11111111,
	0b11111111
};

uint8_t smile[] = {			// 스마일 문자 정의
	0b00111100,
	0b01000010,
	0b10010101,
	0b10100001,
	0b10100001,
	0b10010101,
	0b01000010,
	0b00111100
};

uint8_t hart[] = {		// hart
	0b00000000,    // hart
	0b01100110,
	0b11111111,
	0b11111111,
	0b11111111,
	0b01111110,
	0b00111100,
	0b00011000
};

uint8_t one[] ={
	0b00011000,
	0b00111000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b01111110,
	0b01111110
};

uint8_t my_name[] ={
	0B01111010,
	0B00001010,
	0B00001010,
	0B11111010,
	0B00100010,
	0B10101110,
	0B10000010,
	0B11111110
};

uint8_t fuxku[] = {
	0b00000000,
	0b00000000,
	0b11111000,
	0b11111000,
	0b11111111,
	0b11111000,
	0b01110000,
	0b00000000
};

uint8_t apple[] = {
	0b01111000,
	0b10000100,
	0b10000100,
	0b01001000,
	0b01001010,
	0b10000101,
	0b10110100,
	0b01001000
};

uint8_t col[4]={0,0,0,0};

void dotmatrix_main_test()
{
	uint8_t temp;

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10 | GPIO_PIN_13 | GPIO_PIN_15, 0);
	HAL_Delay(10);

	while (1)
	{
		for (int i=0; i < 8; i++)
		{
			col[0] = ~(1 << i);  // 00000001  --> 11111110
			col[1] = hart[i];
    	    // HAL_SPI_Transmit(&hspi2, col, 2, 1);
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 8; k++)
				{
					temp = col[j];
					if (temp & (1 << k))
					{
						HAL_GPIO_WritePin(GPIOB, SER_74HC595_Pin, 1);
					}
					else
					{
						HAL_GPIO_WritePin(GPIOB, SER_74HC595_Pin, 0);
					}
					HAL_GPIO_WritePin(GPIOB, CLK_74HC595_Pin, 1); // clk을 상승에서
					HAL_GPIO_WritePin(GPIOB, CLK_74HC595_Pin, 0); //       하강으로
				}
			}
    	    GPIOB->ODR &= ~GPIO_PIN_13;   // latch핀을 pull-down
    	    GPIOB->ODR |= GPIO_PIN_13;   // latch핀을 pull-up
    	    HAL_Delay(1);
		}
	}
}
#endif
