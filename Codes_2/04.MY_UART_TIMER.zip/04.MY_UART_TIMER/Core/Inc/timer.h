/*
 * timer.h
 *
 *  Created on: Mar 31, 2025
 *      Author: microsoft
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#include "main.h"

void delay_us(int us);

#endif /* INC_TIMER_H_ */
