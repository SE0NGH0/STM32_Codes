/*
 * dht11.h
 *
 *  Created on: Mar 31, 2025
 *      Author: microsoft
 */

#ifndef INC_DHT11_H_
#define INC_DHT11_H_

#include "main.h"

#define GPIOA_MODER *(unsigned int *)0x40020000
#define GPIOA_OTYPER *(unsigned int *)0x40020004
#define GPIOA_ODR *(unsigned int *)0x40020014
#define GPIOA_IDR *(unsigned int *)0x40020010
#define GPIOA_PUPDR *(unsigned int *)0x4002000C
#define GPIOA_BSRR *(unsigned int *)0x40020018
#define GPIOA_OSPEEDR *(unsigned int *)0x40020008

enum state_define{
    OK,
    TIMEOUT,
    VALUE_ERROR,
    TRANS_ERROR
};
extern enum state_define dht11_state;

// 함수 선언
void init_dht11(void);
void dht11_main(void);
void signal_us_check(int duration, int binary_choice);
int dht11_get_bit(void);

extern uint8_t us_count;

#endif /* INC_DHT11_H_ */
