/*
 * uart.h
 *
 *  Created on: Mar 31, 2025
 *      Author: microsoft
 */

#ifndef INC_UART_H_
#define INC_UART_H_

#include "main.h"

#define COMMAND_NUMBER 20
#define COMMAND_LENGTH 40

// led_all_on\n
// led_all_off\n
volatile uint8_t rx_buff[COMMAND_NUMBER][COMMAND_LENGTH]; // uart0로부터 들어온 문자를 저장하는 버퍼(변수)
volatile int rear = 0; // input index : HAL_UART_RxCpltCallback에서 집어 넣어주는 index
volatile int front = 0; // output index

#endif /* INC_UART_H_ */
